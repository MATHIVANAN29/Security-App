chromium-browser /home/securityapp/frontend/landingBase.html
