const video1 = document.getElementsByClassName('input_video1')[0];
//const video1 = document.querySelector('c.mp4');

const out1 = document.getElementsByClassName('output1')[0];
const controlsElement1 = document.getElementsByClassName('control1')[0];
const canvasCtx1 = out1.getContext('2d');
const fpsControl = new FPS();



let TARGET_IP = 'http://localhost';

//let formData;

var SystemTimeout;



var now = new Date().getTime();
//var countDownDate = new Date().getTime();

var current = new Date(); //'Mar 11 2015' current.getTime() = 1426060964567
var countDownDate = new Date(current.getTime() + 10000);// +15 secs

var distance = countDownDate - now;
var seconds = Math.floor((distance % (1000 * 60)) / 1000);

// Find the distance between now and the count down date

 /* 
// Time calculations for days, hours, minutes and seconds
var days = Math.floor(distance / (1000 * 60 * 60 * 24));
var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
var seconds = Math.floor((distance % (1000 * 60)) / 1000);
*/



const spinner = document.querySelector('.loading');
spinner.ontransitionend = () => {
  spinner.style.display = 'none';
};

function onResultsFace(results) {
  document.body.classList.add('loaded');
  fpsControl.tick();
  canvasCtx1.save();
  canvasCtx1.clearRect(0, 0, out1.width, out1.height);
  canvasCtx1.drawImage( results.image, 0, 0, out1.width, out1.height);

  if (results.detections.length > 0) {
    
     //dont draw for now
    // drawRectangle(
    //     canvasCtx1, results.detections[0].boundingBox,
    //     {color: 'red', lineWidth: 4, fillColor: '#00000000'}
    // );
    
    
    /*    
    drawLandmarks(canvasCtx1, results.detections[0].landmarks, {
      color: 'red',
      radius: 5,
    });
    */



    now = new Date().getTime();
    distance = countDownDate - now;
    seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    if(seconds <= 0) {
      //alert('stable');
      seconds = 0;
      distance = 0;


      //let imgtoSave = canvasCtx1.toDataURL();
      //console.log(imgtoSave);

      //let ctx = out1.getContext('2d');
      let ctx = document.getElementById('output1').getContext('2d');
      ////let ctx = document.getElementsByClassName('output1')[0];
      //let myimg = ctx.toDataURL("image/png");
      let width = 1280;
      let height =720;
      const myImageData = ctx.createImageData(width, height);

      console.log('============= image data ===========');
      console.log(myImageData);



      //var image = ctx.toDataURL("image/png").replace("image/png", "image/octet-stream");  // here is the most important part because if you dont replace you will get a DOM 18 exception.
      //window.location.href=image; 

      // //++++++++++++++++TO DOWNLOAD  +++++++++++++++++++++++++++++++++++++++
      // var link = document.createElement('a');
      // link.download = 'filename.png';
      // link.href = document.getElementById('output1').toDataURL('image/png')
      // link.click();

      // //++++++++++++++++ END TO DOWNLOAD  +++++++++++++++++++++++++++++++++++++++


      //++++++++++++++++ BGIINNNING of POST  +++++++++++++++++++++++++++++++++++++++

      

    //   var file = new File([blob], "user.jpg", {type: "application/octet-stream"});
    //   window.location = URL.createObjectURL(file);
    // }, "image/jpeg", 0.75);  // mime=JPEG, quality=0.75

      

      

      //let myimg = ctx.toDataURL("image/png");
    //   var canvas = document.createElement("canvas");
    // canvas.width = 100;
    // canvas.height = 100;

    // var img = document.createElement("img");
    // img.src = myImageData ;//canvas.toDataURL("image/png");
    // //   document.body.appendChild(img);
    //   formData = new FormData();

    //   formData.append('image', img); 
    //   fetch( 'http://192.168.100.13:5000/verify', {
    //       method: 'POST',
    //       body: formData.get('image')
    //   }).then(response => {
    //       response.json();
    //   }).then(resp => {
    //       console.log(resp);
    //   });




      // Replace "BASE64_IMAGE" with your actual base64-encoded image string
      //const base64Image = myImageData;
      /*
      const base64Image="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA8AAAAPACAYAAAD61hCbAAAAAXNSR0IArs4c6QAAIABJREFUeF7MvQeTnElyJRiZWQoF2Q2guyFaYDizc4Icoxl/+5DLFZwlf8WeGe9suWJ6oEUBJTMrz1w/94gvM9HdQ261oYHK/EQIF++5e0TMfv8P/3nd/If+uW5tRh/M2oz/hq/53/Z93FX/tV6vW6M/wx96KD9YLuHL5Pf0M+MW8DeDb/X+ddc6fAa3A3+oQ/xAeeL1+rpdtyX/bV2bl/fJ7zQWszZvs7Zojf+2tmE/6X34Tu4eP0DeR8+In1lbz9ZtNVs1asXoR66fxSt8rPB5MJ48nGV85c35vTruMnrX3Ob1NYzVrLX5fO7z7/3SCZvr9zyG13S/PV4ebLMiY0F9o791DGfy92wuIzjnW+QBdF83EvQy+ZLbSe+75nG+tinrBcf6y3LYyw/OQycjMH52XZ63eJ312+TYnsXjpZex1MD8c9/19zr+3D+Xoao/dN+8zWfyPJMNGjDRNx1HHScZMNMhkYk5yXB5P8m+t3ZGs3Xd1j7kNB82fzazMaDd2BX5pAeJ1sQcqgLqlNKzl25Tto23DGmMH8vNWiT+p/24AUr64QI31kqXX5N/kV9tF5mYou9T8pPnp9oH0wfRzyn7gPMpY0sGR7XJzXCMUMgjNXTd1vNlazPRuvoWkgyRh9DPpFClXfL2kE+a+TnLQJ6hNekw2Q2yVvMmf3Rur6/FpqyuV/zJYk4Wt/Hv12v6TOWFbc9VWy3P22p52ZbLZXv54lX75//6z+1//Y8/tjdv3rSLs2U7aDfb7HqfnzlbL9re7LjN2p7aEbMrMmLzvUXbOzpsh8c32vHxcds73GvX8+t2ubxsp6en7ez8tF1cnrbV9RU3eNau2+z6ss3aiud8MZu1/dba"
      
      // Convert base64 image to blob
      const byteCharacters = atob(base64Image);
      const byteNumbers = new Array(byteCharacters.length);

      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: "image/png" });

      // Create FormData object and add the blob to it
      const formData = new FormData();
      formData.append("file", blob, "image.png");

      */

      //const data = new Uint32Array();
      // make some noise
      // for(let i = 0; i<data.length; i++) {
      //   data[i] = Math.random() * 0xFFFFFF + 0xFF000000;
      // }
      /*
      const uint8 = new Uint8ClampedArray(myImageData);
      const as_str = [...uint8].map(byte => String.fromCharCode(byte)).join("");
      //const png_str = generatePng(300, 150, as_str);
      const png_str = generatePng(width, height, as_str);
      const png_arr = new Uint8Array(png_str.length);
      for (let i = 0; i < png_str.length; i++) {
        png_arr[i] = png_str.charCodeAt(i);
      }
      const blob = new Blob([png_arr], {type: "image/png"});
      const img2 = new Image();
      img2.src = URL.createObjectURL(blob);
      //document.body.append(img)
      let formData = new FormData();
      formData.append("file", blob, "image.png");
      */

      /*
      // Replace "POST_URL" with your actual URL
        fetch("http://192.168.100.12:5000/verify", {
          method: "POST",
          body: formData,
        })
        .then((response) => {
          console.log("Image posted successfully!");
          console.log(response);
        })
        .catch((error) => {
          console.error("Error posting image:", error);
        });
        */

          /*
        // post 2 trial
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'http://192.168.100.12:5000/verify', true);
        xhr.setRequestHeader('Content-Type', 'image/jpeg');
        xhr.send(blob);
        
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            console.log('Image uploaded successfully!');
          }
        };
        */
      
        /*
        const imageSrc = blob;
        const url = TARGET_IP + ':5000/verify';
        
        fetch(url, {
          method: "POST",
          headers: {
            //"Content-Type": "image/jpeg",
            "Content-Type": "image/png",
            "Access-Control-Allow-Origin": "*" // Set the appropriate cross-origin header value
          },
          body: imageSrc
        })
          .then(response => {
            // Handle the response from the backend
            console.log("Response:", response);

            console.log('Image uploaded successfully!');
            
          })
          .catch(error => {
            // Handle any errors that occurred during the request
            console.error("Error:", error);
          });

          */


          const url = TARGET_IP + ':5000/verify';
          //const url = TARGET_IP + ':9000/detect';
          const canvas = document.getElementById('output1');

          canvas.toBlob(blob => {
            fetch(url, {
                method: 'POST',
                body: blob,
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Success:', data);

                //document.getElementById("uname").innerHTML = data.username;
                document.getElementById("status").innerHTML = "open";

                //location.reload();

                //alert("Gate Opening");
                fetch(TARGET_IP + ':9000/api/user/' + data.username , {
                    method: 'GET'
                }).then(  response => {

                        if (!response.ok) {
                          throw new Error('Network response was not ok');
                      }

                      return response.json();

                }).then(( udata )=> {

                  document.getElementById("uname").innerHTML = udata.username;


                });



                SystemTimeout = setTimeout( () => {

                  document.getElementById("uname").innerHTML  = "-----";
                  document.getElementById("status").innerHTML = "closed";

                },10000);



                //GateOpen();

            })
            .catch(error => {
                console.error('Error:', error);
            });
        });



      //++++++++++++++++ END of POST  +++++++++++++++++++++++++++++++++++++++

      /*
      function download() {
        var link = document.createElement('a');
        link.download = 'filename.png';
        link.href = document.getElementById('canvas').toDataURL('image/png')
        link.click();
      }
    
      download();
      */
      


      /*
      let response = await fetch('http://localhost:8000/image', {
        method: 'POST',
        body: formData
      });
      let result = await response.json();
      */




      //var canvas1 = document.getElementById("canvasSignature");  
      /*      
      if (canvasCtx1.getContext) {
         var ctx = canvasCtx1.getContext("2d");                
         //var myImage = canvasCtx1.toDataURL("image/png");   
         var image = canvasCtx1.toDataURL("image/png").replace("image/png", "image/octet-stream");  // here is the most important part because if you dont replace you will get a DOM 18 exception.
         window.location.href=image;   

         console.log(image);
      }
      */



    }
    
    //console.log("fps: " + JSON.stringify(fpsControl));

    document.getElementById("detecion-time").innerHTML = seconds;
    //document.getElementById("fps-time").innerHTML = fpsControl.counter;
    


    //document.getElementById("demo").innerHTML = "EXPIRED";
  }
  canvasCtx1.restore();

}

function GateOpen(){

  console.log("Opendning Gate .....");

  document.getElementById("uname").innerHTML = data.username;
  document.getElementById("status").innerHTML = "open";
  SystemTimeout = setTimeout(gateClosed,10000);

}

function gateClosed(){

  alert("Gate Closing");

  document.getElementById("uname").innerHTML  = "-----";
  document.getElementById("status").innerHTML = "closed";
}



function stoptimer(){

  clearTimeout(SystemTimeout);



}

const faceDetection = new FaceDetection({locateFile: (file) => {
  return `https://cdn.jsdelivr.net/npm/@mediapipe/face_detection@0.0/${file}`;
}});
faceDetection.onResults(onResultsFace);


const camera = new Camera(video1, {
  onFrame: async () => {
    await faceDetection.send({image: video1});
  },
  width: 480,
  height: 480
});
camera.start();




/*
async function onFrame() {
  if (!video1.paused && !video1.ended) {
    await faceDetection.send({
      image: video1
    });
  // https://stackoverflow.com/questions/65144038/how-to-use-requestanimationframe-with-promise    
    await new Promise(requestAnimationFrame);
    onFrame();
  } else
    setTimeout(onFrame, 500);
}

// must be same domain otherwise it will taint the canvas! 
//video1.src = videob64; 
video1.src= 'd.MOV';

video1.onloadeddata = (evt) => {
  let video = evt.target;

 // canvasElement.width = video.videoWidth;
 // canvasElement.height = video.videoHeight;
 
 const aspect = video.videoHeight / video.videoWidth;
              let width = 960;
              let height = 960;

              if (window.innerWidth > window.innerHeight) {
                height = window.innerHeight;
                width = height / aspect;
              } else {
                width = window.innerWidth;
                height = width * aspect;
              }
              controlsElement1.width = width;
              controlsElement1.height = height;
  
  
  video1.play();
  onFrame();
}
*/




new ControlPanel(controlsElement1, {
      selfieMode: true,
      minDetectionConfidence: 0.5,
    })
    .add([
      new StaticText({title: 'MediaPipe Face Detection'}),
      fpsControl,
      new Toggle({title: 'Selfie Mode', field: 'selfieMode'}),
      new Slider({
        title: 'Min Detection Confidence',
        field: 'minDetectionConfidence',
        range: [0, 1],
        step: 0.01
      }),
    ])
    .on(options => {
      video1.classList.toggle('selfie', options.selfieMode);
      faceDetection.setOptions(options);
    });
